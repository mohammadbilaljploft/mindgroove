"use client";
import React, { useState } from "react";
import Modal from "react-bootstrap/Modal";


export default function Welcome(props) {



    return (
        <>

            <Modal
                show={props.show}          
                onHide={props.onHide}     
                size="md"
                aria-labelledby="contained-modal-title-vcenterc"
                centered
                className="common_modal wclme"
            >
                <Modal.Header closeButton />

                <Modal.Body>
                    <div className="modal_title">
                        <h3>Welcome!</h3>
                        <p>
                            You should be receiving an email from a DO NOT REPLY address momentarily. It 
                            will have login instructions. If you have any questions, or need immediate assistance, 
                            contact us. We look forward to speaking with you!
                        </p>

                        <a href="/" className="main_btn">Ok</a>

                    </div>



                </Modal.Body>
            </Modal>




        </>

    );
}
